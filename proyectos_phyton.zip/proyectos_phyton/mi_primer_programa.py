print(10//3)
print(10//3)
print(3==4)
print(3==4)

